#1. Create a greeting for your program.
print("Welcome to band name generator! Nice to meet you for this software!!")

#2. Ask the user for the city that they grew up in.
city_giving=input("enter you city name where you actually grewed up?\n")
#3. Ask the user for the name of a pet.
petname_giving=input("enter your pet name?\n")
#4. Combine the name of their city and pet and show them their band name.
print("\n your band name is "+ city_giving +" "+petname_giving)
#5. Make sure the input cursor shows on a new line, see the example at:
#   https://replit.com/@appbrewery/band-name-generator-end